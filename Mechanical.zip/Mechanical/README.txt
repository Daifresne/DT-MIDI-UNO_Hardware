Enclosure: 3D printing version
PCB: Internal testing V1.1 version.
Bottom TPU pad: Final.（3D printing tpu)

外壳: 3D打印版
电路板: 内测正式V1.1版本
防滑底垫: 正式版本（3D打印TPU）


